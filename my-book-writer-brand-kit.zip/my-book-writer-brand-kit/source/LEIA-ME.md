# Construção da marca

Mestre atual: EB-Garamond-approved-final.svg. Os glifos são contornos editáveis.
Book e Writer: EB Garamond 600 / 500; MY: Plus Jakarta Sans 600.
Capa: 20 unidades; MY: altura 20; gap horizontal: 3. B com haste 22, topo e base planos.
Os grupos book-cover, my, hybrid-b, ook e writer identificam as partes do mestre.
symbol-construction.svg e micro-construction.svg registram os cortes para ícones.
Fontes originais e licenças: ../docs/fonts/. Medidas e hashes: brand-construction.json.
