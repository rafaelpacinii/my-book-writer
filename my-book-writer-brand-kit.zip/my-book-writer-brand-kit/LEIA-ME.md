# My Book Writer — kit de marca final, EB Garamond

Comece por `preview/kit-overview.png` e `docs/guia-rapido.pdf`.

- `logo/`: horizontal e duas linhas; colorido, escuro, preto, branco e verde; SVG e PNG.
- `icon/`: símbolo normal a partir de 32 px e micro para 16–24 px; SVG e PNG.
- `app/`: ícones desktop, PNG até 1024 px, ICO e ICNS; alternativa quadrada sem máscara.
- `web/`: favicon SVG/ICO/PNG, apple-touch, PWA, maskable, manifest e tags HTML.
- `print/`: PDFs vetoriais RGB da marca horizontal e em duas linhas.
- `docs/`: guia PDF/PNG/Markdown, paleta, tokens CSS, fontes, licenças e validação.
- `preview/`: visão geral, testes de redução e apresentação offline com seis aplicações.
- `source/`: mestre final, construção e desenhos dos ícones.

A capa e o MY têm 20 unidades de altura; há um gap horizontal de 3 unidades entre eles. MY usa Plus Jakarta Sans SemiBold 600. Book usa EB Garamond SemiBold 600 com B personalizado; Writer usa EB Garamond Medium 500 com i em forma de lápis.

Os SVGs da marca e dos ícones têm somente contornos vetoriais, sem depender de fontes instaladas. Fontes originais e licenças estão em `docs/fonts/`.

Para espaços pequenos, use `icon/my-book-writer-micro-green-16.png` ou `-24.png`. Em fundo escuro, escolha white ou sage. O símbolo reduzido omite MY e o micro também omite o marcador.
